# Login_Express_App
This is the project demonstrate login express app created with node and express.

### To run this project clone it and open up the terminal. and type a command,
``` npm install ```

This command will install all the dependancy in the project.
